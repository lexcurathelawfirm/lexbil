'use strict';

const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const db = require('./database');

const isDev = process.env.NODE_ENV === 'development';

function registerIpcHandlers() {
  const handlers = {
    'db:getClients': () => db.getClients(),
    'db:createClient': (_e, data) => db.createClient(data),
    'db:updateClient': (_e, id, data) => db.updateClient(id, data),
    'db:deleteClient': (_e, id) => db.deleteClient(id),

    'db:getMatters': () => db.getMatters(),
    'db:getActiveMatters': () => db.getActiveMatters(),
    'db:createMatter': (_e, data) => db.createMatter(data),
    'db:updateMatter': (_e, id, data) => db.updateMatter(id, data),
    'db:deleteMatter': (_e, id) => db.deleteMatter(id),

    'db:getTimeEntries': () => db.getTimeEntries(),
    'db:createTimeEntry': (_e, data) => db.createTimeEntry(data),
    'db:updateTimeEntry': (_e, id, data) => db.updateTimeEntry(id, data),
    'db:deleteTimeEntry': (_e, id) => db.deleteTimeEntry(id),
    'db:getUnbilledTimeForClient': (_e, clientId) => db.getUnbilledTimeForClient(clientId),

    'db:getExpenses': () => db.getExpenses(),
    'db:createExpense': (_e, data) => db.createExpense(data),
    'db:updateExpense': (_e, id, data) => db.updateExpense(id, data),
    'db:deleteExpense': (_e, id) => db.deleteExpense(id),
    'db:getUnbilledExpensesForClient': (_e, clientId) => db.getUnbilledExpensesForClient(clientId),

    'db:getInvoices': () => db.getInvoices(),
    'db:getInvoice': (_e, id) => db.getInvoice(id),
    'db:createInvoice': (_e, data, items) => db.createInvoice(data, items),
    'db:updateInvoiceStatus': (_e, id, status) => db.updateInvoiceStatus(id, status),
    'db:deleteInvoice': (_e, id) => db.deleteInvoice(id),
    'db:createPayment': (_e, data) => db.createPayment(data),

    'db:getDashboardStats': () => db.getDashboardStats(),
    'db:getRecentInvoices': (_e, limit) => db.getRecentInvoices(limit),
    'db:getRecentUnbilledTime': (_e, limit) => db.getRecentUnbilledTime(limit),

    'db:getProfile': () => db.getProfile(),
    'db:upsertProfile': (_e, data) => db.upsertProfile(data),
    'db:getNextInvoiceNumber': () => db.getNextInvoiceNumber(),
  };

  for (const [channel, handler] of Object.entries(handlers)) {
    ipcMain.handle(channel, handler);
  }
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    title: 'LexBill',
    show: false,
  });

  win.once('ready-to-show', () => win.show());

  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  if (isDev) {
    win.loadURL('http://localhost:5173');
    win.webContents.openDevTools();
  } else {
    win.loadFile(path.join(__dirname, '../dist/index.html'));
  }
}

app.whenReady().then(() => {
  const dbPath = path.join(app.getPath('userData'), 'lexbill.db');
  db.init(dbPath);
  registerIpcHandlers();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
