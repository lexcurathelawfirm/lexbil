'use strict';

const { randomUUID } = require('crypto');

let db;

function init(dbPath) {
  const Database = require('better-sqlite3');
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  createTables();
}

function createTables() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS advocate_profile (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL DEFAULT '',
      practice_name TEXT NOT NULL DEFAULT '',
      bar_council_number TEXT NOT NULL DEFAULT '',
      address TEXT NOT NULL DEFAULT '',
      phone TEXT NOT NULL DEFAULT '',
      email TEXT NOT NULL DEFAULT '',
      gstin TEXT NOT NULL DEFAULT '',
      bank_name TEXT NOT NULL DEFAULT '',
      bank_account TEXT NOT NULL DEFAULT '',
      bank_ifsc TEXT NOT NULL DEFAULT '',
      invoice_prefix TEXT NOT NULL DEFAULT 'INV',
      invoice_counter INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS clients (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL DEFAULT '',
      phone TEXT NOT NULL DEFAULT '',
      address TEXT NOT NULL DEFAULT '',
      gstin TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS matters (
      id TEXT PRIMARY KEY,
      client_id TEXT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      case_number TEXT NOT NULL DEFAULT '',
      court TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'active',
      hourly_rate REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS time_entries (
      id TEXT PRIMARY KEY,
      matter_id TEXT NOT NULL REFERENCES matters(id) ON DELETE CASCADE,
      date TEXT NOT NULL,
      hours REAL NOT NULL,
      description TEXT NOT NULL,
      rate REAL NOT NULL DEFAULT 0,
      billed INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS expenses (
      id TEXT PRIMARY KEY,
      matter_id TEXT NOT NULL REFERENCES matters(id) ON DELETE CASCADE,
      date TEXT NOT NULL,
      description TEXT NOT NULL,
      amount REAL NOT NULL,
      billed INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS invoices (
      id TEXT PRIMARY KEY,
      client_id TEXT NOT NULL REFERENCES clients(id) ON DELETE RESTRICT,
      invoice_number TEXT NOT NULL UNIQUE,
      issue_date TEXT NOT NULL,
      due_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'draft',
      subtotal REAL NOT NULL DEFAULT 0,
      tax_rate REAL NOT NULL DEFAULT 18,
      tax_amount REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS invoice_items (
      id TEXT PRIMARY KEY,
      invoice_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
      description TEXT NOT NULL,
      quantity REAL NOT NULL DEFAULT 1,
      rate REAL NOT NULL DEFAULT 0,
      amount REAL NOT NULL DEFAULT 0,
      time_entry_id TEXT,
      expense_id TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      invoice_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
      date TEXT NOT NULL,
      amount REAL NOT NULL,
      method TEXT NOT NULL DEFAULT 'bank_transfer',
      reference TEXT NOT NULL DEFAULT '',
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
}

// Advocate profile
function getProfile() {
  return db.prepare('SELECT * FROM advocate_profile LIMIT 1').get() ?? null;
}

function upsertProfile(data) {
  const existing = db.prepare('SELECT id FROM advocate_profile LIMIT 1').get();
  if (existing) {
    db.prepare(`
      UPDATE advocate_profile SET
        name=@name, practice_name=@practice_name, bar_council_number=@bar_council_number,
        address=@address, phone=@phone, email=@email, gstin=@gstin,
        bank_name=@bank_name, bank_account=@bank_account, bank_ifsc=@bank_ifsc,
        invoice_prefix=@invoice_prefix, updated_at=datetime('now')
      WHERE id=@id
    `).run({ ...data, id: existing.id });
  } else {
    db.prepare(`
      INSERT INTO advocate_profile (id, name, practice_name, bar_council_number, address, phone, email, gstin, bank_name, bank_account, bank_ifsc, invoice_prefix)
      VALUES (@id, @name, @practice_name, @bar_council_number, @address, @phone, @email, @gstin, @bank_name, @bank_account, @bank_ifsc, @invoice_prefix)
    `).run({ id: randomUUID(), ...data });
  }
  return getProfile();
}

function getNextInvoiceNumber() {
  const profile = getProfile();
  const prefix = profile?.invoice_prefix ?? 'INV';
  const counter = profile?.invoice_counter ?? 1;
  const number = `${prefix}-${String(counter).padStart(4, '0')}`;
  if (profile) {
    db.prepare('UPDATE advocate_profile SET invoice_counter=? WHERE id=?').run(counter + 1, profile.id);
  } else {
    db.prepare(`INSERT INTO advocate_profile (id, invoice_prefix, invoice_counter) VALUES (?,?,?)`).run(randomUUID(), prefix, counter + 1);
  }
  return number;
}

// Clients
function getClients() {
  return db.prepare('SELECT * FROM clients ORDER BY name').all();
}

function createClient(data) {
  const id = randomUUID();
  db.prepare('INSERT INTO clients (id, name, email, phone, address, gstin) VALUES (@id,@name,@email,@phone,@address,@gstin)').run({ id, ...data });
  return db.prepare('SELECT * FROM clients WHERE id=?').get(id);
}

function updateClient(id, data) {
  db.prepare("UPDATE clients SET name=@name, email=@email, phone=@phone, address=@address, gstin=@gstin, updated_at=datetime('now') WHERE id=@id").run({ id, ...data });
  return db.prepare('SELECT * FROM clients WHERE id=?').get(id);
}

function deleteClient(id) {
  db.prepare('DELETE FROM clients WHERE id=?').run(id);
}

// Matters
function getMatters() {
  return db.prepare(`
    SELECT m.*, c.id as client_id, c.name as client_name
    FROM matters m LEFT JOIN clients c ON m.client_id=c.id
    ORDER BY m.created_at DESC
  `).all().map(row => ({
    ...row,
    client: { id: row.client_id, name: row.client_name },
  }));
}

function getActiveMatters() {
  return db.prepare(`
    SELECT m.*, c.name as client_name
    FROM matters m LEFT JOIN clients c ON m.client_id=c.id
    WHERE m.status='active'
    ORDER BY m.title
  `).all().map(row => ({
    ...row,
    client: { name: row.client_name },
  }));
}

function createMatter(data) {
  const id = randomUUID();
  db.prepare('INSERT INTO matters (id, client_id, title, description, case_number, court, status, hourly_rate) VALUES (@id,@client_id,@title,@description,@case_number,@court,@status,@hourly_rate)').run({ id, ...data });
  return db.prepare('SELECT * FROM matters WHERE id=?').get(id);
}

function updateMatter(id, data) {
  db.prepare("UPDATE matters SET client_id=@client_id, title=@title, description=@description, case_number=@case_number, court=@court, status=@status, hourly_rate=@hourly_rate, updated_at=datetime('now') WHERE id=@id").run({ id, ...data });
  return db.prepare('SELECT * FROM matters WHERE id=?').get(id);
}

function deleteMatter(id) {
  db.prepare('DELETE FROM matters WHERE id=?').run(id);
}

// Time entries
function getTimeEntries() {
  return db.prepare(`
    SELECT t.*, m.title as matter_title, m.hourly_rate as matter_rate, c.name as client_name
    FROM time_entries t
    LEFT JOIN matters m ON t.matter_id=m.id
    LEFT JOIN clients c ON m.client_id=c.id
    ORDER BY t.date DESC, t.created_at DESC
  `).all().map(row => ({
    ...row,
    billed: row.billed === 1,
    matter: { title: row.matter_title, hourly_rate: row.matter_rate, client: { name: row.client_name } },
  }));
}

function createTimeEntry(data) {
  const id = randomUUID();
  db.prepare('INSERT INTO time_entries (id, matter_id, date, hours, description, rate) VALUES (@id,@matter_id,@date,@hours,@description,@rate)').run({ id, ...data });
  return db.prepare('SELECT * FROM time_entries WHERE id=?').get(id);
}

function updateTimeEntry(id, data) {
  db.prepare('UPDATE time_entries SET matter_id=@matter_id, date=@date, hours=@hours, description=@description, rate=@rate WHERE id=@id').run({ id, ...data });
  return db.prepare('SELECT * FROM time_entries WHERE id=?').get(id);
}

function deleteTimeEntry(id) {
  db.prepare('DELETE FROM time_entries WHERE id=?').run(id);
}

function getUnbilledTimeForClient(clientId) {
  return db.prepare(`
    SELECT t.*, m.title as matter_title
    FROM time_entries t
    LEFT JOIN matters m ON t.matter_id=m.id
    WHERE m.client_id=? AND t.billed=0
    ORDER BY t.date DESC
  `).all(clientId).map(row => ({
    ...row,
    billed: false,
    matter: { title: row.matter_title },
  }));
}

// Expenses
function getExpenses() {
  return db.prepare(`
    SELECT e.*, m.title as matter_title, c.name as client_name
    FROM expenses e
    LEFT JOIN matters m ON e.matter_id=m.id
    LEFT JOIN clients c ON m.client_id=c.id
    ORDER BY e.date DESC, e.created_at DESC
  `).all().map(row => ({
    ...row,
    billed: row.billed === 1,
    matter: { title: row.matter_title, client: { name: row.client_name } },
  }));
}

function createExpense(data) {
  const id = randomUUID();
  db.prepare('INSERT INTO expenses (id, matter_id, date, description, amount) VALUES (@id,@matter_id,@date,@description,@amount)').run({ id, ...data });
  return db.prepare('SELECT * FROM expenses WHERE id=?').get(id);
}

function updateExpense(id, data) {
  db.prepare('UPDATE expenses SET matter_id=@matter_id, date=@date, description=@description, amount=@amount WHERE id=@id').run({ id, ...data });
  return db.prepare('SELECT * FROM expenses WHERE id=?').get(id);
}

function deleteExpense(id) {
  db.prepare('DELETE FROM expenses WHERE id=?').run(id);
}

function getUnbilledExpensesForClient(clientId) {
  return db.prepare(`
    SELECT e.*, m.title as matter_title
    FROM expenses e
    LEFT JOIN matters m ON e.matter_id=m.id
    WHERE m.client_id=? AND e.billed=0
    ORDER BY e.date DESC
  `).all(clientId).map(row => ({
    ...row,
    billed: false,
    matter: { title: row.matter_title },
  }));
}

// Invoices
function getInvoices() {
  return db.prepare(`
    SELECT i.*, c.id as cid, c.name as client_name, c.email as client_email, c.address as client_address, c.gstin as client_gstin
    FROM invoices i LEFT JOIN clients c ON i.client_id=c.id
    ORDER BY i.created_at DESC
  `).all().map(row => ({
    ...row,
    client: { id: row.cid, name: row.client_name, email: row.client_email, address: row.client_address, gstin: row.client_gstin },
  }));
}

function getInvoice(id) {
  const inv = db.prepare(`
    SELECT i.*, c.id as cid, c.name as client_name, c.email as client_email, c.phone as client_phone, c.address as client_address, c.gstin as client_gstin
    FROM invoices i LEFT JOIN clients c ON i.client_id=c.id
    WHERE i.id=?
  `).get(id);
  if (!inv) return null;
  const items = db.prepare('SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY created_at').all(id);
  const payments = db.prepare('SELECT * FROM payments WHERE invoice_id=? ORDER BY date').all(id);
  return {
    ...inv,
    client: { id: inv.cid, name: inv.client_name, email: inv.client_email, phone: inv.client_phone, address: inv.client_address, gstin: inv.client_gstin },
    items,
    payments,
  };
}

function createInvoice(data, items) {
  const invoiceId = randomUUID();
  const createInvoiceTx = db.transaction(() => {
    db.prepare(`
      INSERT INTO invoices (id, client_id, invoice_number, issue_date, due_date, status, subtotal, tax_rate, tax_amount, total, notes)
      VALUES (@id, @client_id, @invoice_number, @issue_date, @due_date, @status, @subtotal, @tax_rate, @tax_amount, @total, @notes)
    `).run({ id: invoiceId, ...data });

    for (const item of items) {
      db.prepare(`
        INSERT INTO invoice_items (id, invoice_id, description, quantity, rate, amount, time_entry_id, expense_id)
        VALUES (@id, @invoice_id, @description, @quantity, @rate, @amount, @time_entry_id, @expense_id)
      `).run({ id: randomUUID(), invoice_id: invoiceId, ...item, time_entry_id: item.time_entry_id ?? null, expense_id: item.expense_id ?? null });
    }

    const timeIds = items.filter(i => i.time_entry_id).map(i => i.time_entry_id);
    const expIds = items.filter(i => i.expense_id).map(i => i.expense_id);

    for (const tid of timeIds) {
      db.prepare('UPDATE time_entries SET billed=1 WHERE id=?').run(tid);
    }
    for (const eid of expIds) {
      db.prepare('UPDATE expenses SET billed=1 WHERE id=?').run(eid);
    }
  });
  createInvoiceTx();
  return getInvoice(invoiceId);
}

function updateInvoiceStatus(id, status) {
  db.prepare("UPDATE invoices SET status=?, updated_at=datetime('now') WHERE id=?").run(status, id);
}

function deleteInvoice(id) {
  db.prepare('DELETE FROM invoices WHERE id=?').run(id);
}

function createPayment(data) {
  const id = randomUUID();
  db.prepare('INSERT INTO payments (id, invoice_id, date, amount, method, reference, notes) VALUES (@id,@invoice_id,@date,@amount,@method,@reference,@notes)').run({ id, ...data });

  // Auto-mark as paid if fully paid
  const inv = db.prepare('SELECT total FROM invoices WHERE id=?').get(data.invoice_id);
  const paid = db.prepare('SELECT SUM(amount) as s FROM payments WHERE invoice_id=?').get(data.invoice_id);
  if (inv && paid && paid.s >= inv.total) {
    db.prepare("UPDATE invoices SET status='paid', updated_at=datetime('now') WHERE id=?").run(data.invoice_id);
  }
  return db.prepare('SELECT * FROM payments WHERE id=?').get(id);
}

function getDashboardStats() {
  const totalClients = db.prepare('SELECT COUNT(*) as n FROM clients').get().n;
  const activeMatters = db.prepare("SELECT COUNT(*) as n FROM matters WHERE status='active'").get().n;
  const allInvoices = db.prepare('SELECT status, total FROM invoices').all();
  const openInvoices = allInvoices.filter(i => ['sent', 'overdue'].includes(i.status));
  const totalOutstanding = openInvoices.reduce((s, i) => s + i.total, 0);
  const overdueAmount = allInvoices.filter(i => i.status === 'overdue').reduce((s, i) => s + i.total, 0);
  const unbilledRows = db.prepare('SELECT hours FROM time_entries WHERE billed=0').all();
  const unbilledHours = unbilledRows.reduce((s, r) => s + r.hours, 0);
  return { totalClients, activeMatters, openInvoices: openInvoices.length, totalOutstanding, unbilledHours, overdueAmount };
}

function getRecentInvoices(limit) {
  return db.prepare(`
    SELECT i.*, c.name as client_name
    FROM invoices i LEFT JOIN clients c ON i.client_id=c.id
    ORDER BY i.created_at DESC LIMIT ?
  `).all(limit ?? 5).map(row => ({ ...row, client: { name: row.client_name } }));
}

function getRecentUnbilledTime(limit) {
  return db.prepare(`
    SELECT t.*, m.title as matter_title, c.name as client_name
    FROM time_entries t
    LEFT JOIN matters m ON t.matter_id=m.id
    LEFT JOIN clients c ON m.client_id=c.id
    WHERE t.billed=0
    ORDER BY t.date DESC LIMIT ?
  `).all(limit ?? 5).map(row => ({
    ...row,
    billed: false,
    matter: { title: row.matter_title, client: { name: row.client_name } },
  }));
}

module.exports = {
  init, getProfile, upsertProfile, getNextInvoiceNumber,
  getClients, createClient, updateClient, deleteClient,
  getMatters, getActiveMatters, createMatter, updateMatter, deleteMatter,
  getTimeEntries, createTimeEntry, updateTimeEntry, deleteTimeEntry, getUnbilledTimeForClient,
  getExpenses, createExpense, updateExpense, deleteExpense, getUnbilledExpensesForClient,
  getInvoices, getInvoice, createInvoice, updateInvoiceStatus, deleteInvoice, createPayment,
  getDashboardStats, getRecentInvoices, getRecentUnbilledTime,
};
