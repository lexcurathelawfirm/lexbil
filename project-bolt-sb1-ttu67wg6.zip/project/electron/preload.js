'use strict';

const { contextBridge, ipcRenderer } = require('electron');

const invoke = (channel, ...args) => ipcRenderer.invoke(channel, ...args);

contextBridge.exposeInMainWorld('electronAPI', {
  getClients: () => invoke('db:getClients'),
  createClient: (data) => invoke('db:createClient', data),
  updateClient: (id, data) => invoke('db:updateClient', id, data),
  deleteClient: (id) => invoke('db:deleteClient', id),

  getMatters: () => invoke('db:getMatters'),
  getActiveMatters: () => invoke('db:getActiveMatters'),
  createMatter: (data) => invoke('db:createMatter', data),
  updateMatter: (id, data) => invoke('db:updateMatter', id, data),
  deleteMatter: (id) => invoke('db:deleteMatter', id),

  getTimeEntries: () => invoke('db:getTimeEntries'),
  createTimeEntry: (data) => invoke('db:createTimeEntry', data),
  updateTimeEntry: (id, data) => invoke('db:updateTimeEntry', id, data),
  deleteTimeEntry: (id) => invoke('db:deleteTimeEntry', id),
  getUnbilledTimeForClient: (clientId) => invoke('db:getUnbilledTimeForClient', clientId),

  getExpenses: () => invoke('db:getExpenses'),
  createExpense: (data) => invoke('db:createExpense', data),
  updateExpense: (id, data) => invoke('db:updateExpense', id, data),
  deleteExpense: (id) => invoke('db:deleteExpense', id),
  getUnbilledExpensesForClient: (clientId) => invoke('db:getUnbilledExpensesForClient', clientId),

  getInvoices: () => invoke('db:getInvoices'),
  getInvoice: (id) => invoke('db:getInvoice', id),
  createInvoice: (data, items) => invoke('db:createInvoice', data, items),
  updateInvoiceStatus: (id, status) => invoke('db:updateInvoiceStatus', id, status),
  deleteInvoice: (id) => invoke('db:deleteInvoice', id),
  createPayment: (data) => invoke('db:createPayment', data),

  getDashboardStats: () => invoke('db:getDashboardStats'),
  getRecentInvoices: (limit) => invoke('db:getRecentInvoices', limit),
  getRecentUnbilledTime: (limit) => invoke('db:getRecentUnbilledTime', limit),

  getProfile: () => invoke('db:getProfile'),
  upsertProfile: (data) => invoke('db:upsertProfile', data),
  getNextInvoiceNumber: () => invoke('db:getNextInvoiceNumber'),
});
