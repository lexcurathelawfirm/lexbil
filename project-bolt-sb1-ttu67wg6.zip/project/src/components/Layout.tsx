import { useState } from 'react';
import {
  Scale, LayoutDashboard, Users, Briefcase, Clock, FileText,
  Settings, Menu, X, ChevronRight, HardDrive
} from 'lucide-react';

type Page = 'dashboard' | 'clients' | 'matters' | 'time' | 'invoices' | 'settings';

interface LayoutProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
  children: React.ReactNode;
}

const navItems = [
  { id: 'dashboard' as Page, label: 'Dashboard', icon: LayoutDashboard },
  { id: 'clients' as Page, label: 'Clients', icon: Users },
  { id: 'matters' as Page, label: 'Matters', icon: Briefcase },
  { id: 'time' as Page, label: 'Time & Expenses', icon: Clock },
  { id: 'invoices' as Page, label: 'Invoices', icon: FileText },
  { id: 'settings' as Page, label: 'Settings', icon: Settings },
];

export type { Page };

export default function Layout({ currentPage, onNavigate, children }: LayoutProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  function NavContent() {
    return (
      <>
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-5 border-b border-slate-800">
          <div className="flex items-center justify-center w-9 h-9 bg-amber-500 rounded-xl flex-shrink-0">
            <Scale className="w-5 h-5 text-slate-900" />
          </div>
          <div>
            <p className="text-white font-bold text-sm leading-tight">LexBill</p>
            <p className="text-slate-500 text-xs">Billing System</p>
          </div>
        </div>

        {/* Nav items */}
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {navItems.map(({ id, label, icon: Icon }) => {
            const active = currentPage === id;
            return (
              <button
                key={id}
                onClick={() => { onNavigate(id); setMobileOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group ${
                  active
                    ? 'bg-amber-500/15 text-amber-400'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <Icon className={`w-4 h-4 flex-shrink-0 ${active ? 'text-amber-400' : 'text-slate-500 group-hover:text-slate-300'}`} />
                <span className="flex-1 text-left">{label}</span>
                {active && <ChevronRight className="w-3 h-3 text-amber-400/60" />}
              </button>
            );
          })}
        </nav>

        {/* Local storage indicator */}
        <div className="px-3 pb-4 border-t border-slate-800 pt-4">
          <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-slate-800/60">
            <HardDrive className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
            <p className="text-slate-500 text-xs leading-snug">Data stored locally on your device</p>
          </div>
        </div>
      </>
    );
  }

  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden">
      {/* Sidebar - desktop */}
      <aside className="hidden lg:flex flex-col w-56 bg-slate-900 border-r border-slate-800 flex-shrink-0">
        <NavContent />
      </aside>

      {/* Mobile sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <aside className="relative flex flex-col w-56 h-full bg-slate-900 border-r border-slate-800">
            <button
              onClick={() => setMobileOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
            <NavContent />
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile header */}
        <header className="lg:hidden flex items-center gap-4 px-4 py-3 bg-slate-900 border-b border-slate-800">
          <button onClick={() => setMobileOpen(true)} className="text-slate-400 hover:text-slate-200">
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-7 h-7 bg-amber-500 rounded-lg">
              <Scale className="w-4 h-4 text-slate-900" />
            </div>
            <span className="text-white font-bold text-sm">LexBill</span>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
