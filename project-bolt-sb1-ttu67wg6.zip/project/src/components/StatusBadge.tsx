interface StatusBadgeProps {
  status: string;
}

const configs: Record<string, { label: string; className: string }> = {
  active: { label: 'Active', className: 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20' },
  closed: { label: 'Closed', className: 'bg-slate-700/60 text-slate-400 border border-slate-600/40' },
  on_hold: { label: 'On Hold', className: 'bg-orange-500/15 text-orange-400 border border-orange-500/20' },
  draft: { label: 'Draft', className: 'bg-slate-700/60 text-slate-400 border border-slate-600/40' },
  sent: { label: 'Sent', className: 'bg-blue-500/15 text-blue-400 border border-blue-500/20' },
  paid: { label: 'Paid', className: 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20' },
  overdue: { label: 'Overdue', className: 'bg-red-500/15 text-red-400 border border-red-500/20' },
  cancelled: { label: 'Cancelled', className: 'bg-slate-700/60 text-slate-400 border border-slate-600/40' },
};

export default function StatusBadge({ status }: StatusBadgeProps) {
  const config = configs[status] ?? { label: status, className: 'bg-slate-700 text-slate-300' };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium ${config.className}`}>
      {config.label}
    </span>
  );
}
