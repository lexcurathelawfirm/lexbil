import type { AdvocateProfile, Client, Matter, TimeEntry, Expense, Invoice, InvoiceItem, Payment, InvoiceStatus } from '../types';

interface ElectronAPI {
  getClients: () => Promise<Client[]>;
  createClient: (data: Omit<Client, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => Promise<Client>;
  updateClient: (id: string, data: Omit<Client, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => Promise<Client>;
  deleteClient: (id: string) => Promise<void>;

  getMatters: () => Promise<Matter[]>;
  getActiveMatters: () => Promise<Matter[]>;
  createMatter: (data: Omit<Matter, 'id' | 'user_id' | 'created_at' | 'updated_at' | 'client'>) => Promise<Matter>;
  updateMatter: (id: string, data: Omit<Matter, 'id' | 'user_id' | 'created_at' | 'updated_at' | 'client'>) => Promise<Matter>;
  deleteMatter: (id: string) => Promise<void>;

  getTimeEntries: () => Promise<TimeEntry[]>;
  createTimeEntry: (data: Omit<TimeEntry, 'id' | 'user_id' | 'billed' | 'created_at' | 'matter'>) => Promise<TimeEntry>;
  updateTimeEntry: (id: string, data: Omit<TimeEntry, 'id' | 'user_id' | 'billed' | 'created_at' | 'matter'>) => Promise<TimeEntry>;
  deleteTimeEntry: (id: string) => Promise<void>;
  getUnbilledTimeForClient: (clientId: string) => Promise<TimeEntry[]>;

  getExpenses: () => Promise<Expense[]>;
  createExpense: (data: Omit<Expense, 'id' | 'user_id' | 'billed' | 'created_at' | 'matter'>) => Promise<Expense>;
  updateExpense: (id: string, data: Omit<Expense, 'id' | 'user_id' | 'billed' | 'created_at' | 'matter'>) => Promise<Expense>;
  deleteExpense: (id: string) => Promise<void>;
  getUnbilledExpensesForClient: (clientId: string) => Promise<Expense[]>;

  getInvoices: () => Promise<Invoice[]>;
  getInvoice: (id: string) => Promise<Invoice & { items: InvoiceItem[]; payments: Payment[] } | null>;
  createInvoice: (data: Omit<Invoice, 'id' | 'user_id' | 'created_at' | 'updated_at' | 'client' | 'items' | 'payments'>, items: Omit<InvoiceItem, 'id' | 'created_at'>[]) => Promise<Invoice>;
  updateInvoiceStatus: (id: string, status: InvoiceStatus) => Promise<void>;
  deleteInvoice: (id: string) => Promise<void>;
  createPayment: (data: Omit<Payment, 'id' | 'created_at'>) => Promise<Payment>;

  getDashboardStats: () => Promise<{ totalClients: number; activeMatters: number; openInvoices: number; totalOutstanding: number; unbilledHours: number; overdueAmount: number }>;
  getRecentInvoices: (limit?: number) => Promise<Invoice[]>;
  getRecentUnbilledTime: (limit?: number) => Promise<TimeEntry[]>;

  getProfile: () => Promise<AdvocateProfile | null>;
  upsertProfile: (data: Omit<AdvocateProfile, 'id' | 'user_id' | 'created_at' | 'updated_at' | 'invoice_counter'>) => Promise<AdvocateProfile>;
  getNextInvoiceNumber: () => Promise<string>;
}

declare global {
  interface Window {
    electronAPI: ElectronAPI;
  }
}

export const api: ElectronAPI = window.electronAPI;
