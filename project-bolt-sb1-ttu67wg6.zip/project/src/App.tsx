import { useState } from 'react';
import Layout, { type Page } from './components/Layout';
import Dashboard from './pages/Dashboard';
import Clients from './pages/Clients';
import Matters from './pages/Matters';
import TimeEntries from './pages/TimeEntries';
import Invoices from './pages/Invoices';
import InvoiceView from './pages/InvoiceView';
import Settings from './pages/Settings';

export default function App() {
  const [page, setPage] = useState<Page>('dashboard');
  const [viewingInvoice, setViewingInvoice] = useState<string | null>(null);

  if (viewingInvoice) {
    return (
      <InvoiceView
        invoiceId={viewingInvoice}
        onBack={() => setViewingInvoice(null)}
      />
    );
  }

  return (
    <Layout currentPage={page} onNavigate={setPage}>
      {page === 'dashboard' && <Dashboard onNavigate={setPage} />}
      {page === 'clients' && <Clients />}
      {page === 'matters' && <Matters />}
      {page === 'time' && <TimeEntries />}
      {page === 'invoices' && <Invoices onView={id => setViewingInvoice(id)} />}
      {page === 'settings' && <Settings />}
    </Layout>
  );
}
