export interface AdvocateProfile {
  id: string;
  user_id: string;
  name: string;
  practice_name: string;
  bar_council_number: string;
  address: string;
  phone: string;
  email: string;
  gstin: string;
  bank_name: string;
  bank_account: string;
  bank_ifsc: string;
  invoice_prefix: string;
  invoice_counter: number;
  created_at: string;
  updated_at: string;
}

export interface Client {
  id: string;
  user_id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  gstin: string;
  created_at: string;
  updated_at: string;
}

export type MatterStatus = 'active' | 'closed' | 'on_hold';

export interface Matter {
  id: string;
  user_id: string;
  client_id: string;
  title: string;
  description: string;
  case_number: string;
  court: string;
  status: MatterStatus;
  hourly_rate: number;
  created_at: string;
  updated_at: string;
  client?: Client;
}

export interface TimeEntry {
  id: string;
  user_id: string;
  matter_id: string;
  date: string;
  hours: number;
  description: string;
  rate: number;
  billed: boolean;
  created_at: string;
  matter?: Matter & { client?: Client };
}

export interface Expense {
  id: string;
  user_id: string;
  matter_id: string;
  date: string;
  description: string;
  amount: number;
  billed: boolean;
  created_at: string;
  matter?: Matter & { client?: Client };
}

export type InvoiceStatus = 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled';

export interface Invoice {
  id: string;
  user_id: string;
  client_id: string;
  invoice_number: string;
  issue_date: string;
  due_date: string;
  status: InvoiceStatus;
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  total: number;
  notes: string;
  created_at: string;
  updated_at: string;
  client?: Client;
  items?: InvoiceItem[];
  payments?: Payment[];
}

export interface InvoiceItem {
  id: string;
  invoice_id: string;
  description: string;
  quantity: number;
  rate: number;
  amount: number;
  time_entry_id: string | null;
  expense_id: string | null;
  created_at: string;
}

export interface Payment {
  id: string;
  invoice_id: string;
  date: string;
  amount: number;
  method: string;
  reference: string;
  notes: string;
  created_at: string;
}
