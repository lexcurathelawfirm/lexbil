import { useEffect, useState } from 'react';
import { Plus, Clock, Trash2, Pencil, Receipt } from 'lucide-react';
import { api } from '../lib/api';
import Modal from '../components/Modal';
import type { TimeEntry, Expense, Matter } from '../types';

type Tab = 'time' | 'expenses';

function fmt(n: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
}

function fmtDate(s: string) {
  return new Date(s + 'T00:00:00').toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

const emptyTime = { matter_id: '', date: new Date().toISOString().slice(0, 10), hours: '', description: '', rate: '' };
const emptyExp = { matter_id: '', date: new Date().toISOString().slice(0, 10), description: '', amount: '' };

export default function TimeEntries() {
  const [tab, setTab] = useState<Tab>('time');
  const [matters, setMatters] = useState<Matter[]>([]);
  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);

  const [timeModal, setTimeModal] = useState(false);
  const [expModal, setExpModal] = useState(false);
  const [editingTime, setEditingTime] = useState<TimeEntry | null>(null);
  const [editingExp, setEditingExp] = useState<Expense | null>(null);
  const [timeForm, setTimeForm] = useState(emptyTime);
  const [expForm, setExpForm] = useState(emptyExp);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [deleteId, setDeleteId] = useState<{ type: Tab; id: string } | null>(null);

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    const [m, t, e] = await Promise.all([
      api.getActiveMatters(),
      api.getTimeEntries(),
      api.getExpenses(),
    ]);
    setMatters(m);
    setTimeEntries(t);
    setExpenses(e);
    setLoading(false);
  }

  function openTimeCreate() {
    const m = matters[0];
    setEditingTime(null);
    setTimeForm({ ...emptyTime, matter_id: m?.id ?? '', rate: String(m?.hourly_rate ?? '') });
    setError('');
    setTimeModal(true);
  }

  function openTimeEdit(e: TimeEntry) {
    setEditingTime(e);
    setTimeForm({ matter_id: e.matter_id, date: e.date, hours: String(e.hours), description: e.description, rate: String(e.rate) });
    setError('');
    setTimeModal(true);
  }

  async function saveTime() {
    if (!timeForm.matter_id) { setError('Select a matter.'); return; }
    if (!timeForm.description.trim()) { setError('Description is required.'); return; }
    if (!timeForm.hours) { setError('Hours is required.'); return; }
    setSaving(true);
    setError('');
    const payload = {
      matter_id: timeForm.matter_id,
      date: timeForm.date,
      hours: parseFloat(timeForm.hours),
      description: timeForm.description,
      rate: parseFloat(timeForm.rate) || 0,
    };
    try {
      if (editingTime) {
        await api.updateTimeEntry(editingTime.id, payload);
      } else {
        await api.createTimeEntry(payload);
      }
      setTimeModal(false);
      load();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  function openExpCreate() {
    setEditingExp(null);
    setExpForm({ ...emptyExp, matter_id: matters[0]?.id ?? '' });
    setError('');
    setExpModal(true);
  }

  function openExpEdit(e: Expense) {
    setEditingExp(e);
    setExpForm({ matter_id: e.matter_id, date: e.date, description: e.description, amount: String(e.amount) });
    setError('');
    setExpModal(true);
  }

  async function saveExp() {
    if (!expForm.matter_id) { setError('Select a matter.'); return; }
    if (!expForm.description.trim()) { setError('Description is required.'); return; }
    if (!expForm.amount) { setError('Amount is required.'); return; }
    setSaving(true);
    setError('');
    const payload = { matter_id: expForm.matter_id, date: expForm.date, description: expForm.description, amount: parseFloat(expForm.amount) };
    try {
      if (editingExp) {
        await api.updateExpense(editingExp.id, payload);
      } else {
        await api.createExpense(payload);
      }
      setExpModal(false);
      load();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteId) return;
    if (deleteId.type === 'time') {
      await api.deleteTimeEntry(deleteId.id);
    } else {
      await api.deleteExpense(deleteId.id);
    }
    setDeleteId(null);
    load();
  }

  const unbilledHours = timeEntries.filter(e => !e.billed).reduce((s, e) => s + Number(e.hours), 0);
  const unbilledValue = timeEntries.filter(e => !e.billed).reduce((s, e) => s + Number(e.hours) * Number(e.rate), 0);
  const unbilledExp = expenses.filter(e => !e.billed).reduce((s, e) => s + Number(e.amount), 0);

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Time & Expenses</h1>
          <p className="text-slate-400 text-sm mt-1">Track billable time and out-of-pocket expenses</p>
        </div>
        <button
          onClick={() => tab === 'time' ? openTimeCreate() : openExpCreate()}
          className="flex items-center gap-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold px-4 py-2 rounded-lg text-sm transition-colors"
        >
          <Plus className="w-4 h-4" />
          {tab === 'time' ? 'Log Time' : 'Add Expense'}
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <p className="text-2xl font-bold text-amber-400">{unbilledHours.toFixed(1)}h</p>
          <p className="text-slate-500 text-xs mt-1">Unbilled Hours</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <p className="text-2xl font-bold text-emerald-400">{fmt(unbilledValue)}</p>
          <p className="text-slate-500 text-xs mt-1">Unbilled Fees</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <p className="text-2xl font-bold text-blue-400">{fmt(unbilledExp)}</p>
          <p className="text-slate-500 text-xs mt-1">Unbilled Expenses</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 bg-slate-900 border border-slate-800 rounded-lg p-1 w-fit">
        {[{ id: 'time' as Tab, label: 'Time Entries', icon: Clock }, { id: 'expenses' as Tab, label: 'Expenses', icon: Receipt }].map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
              tab === id ? 'bg-slate-800 text-white' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-500 text-sm">Loading...</div>
        ) : tab === 'time' ? (
          timeEntries.length === 0 ? (
            <div className="p-12 text-center">
              <Clock className="w-10 h-10 text-slate-700 mx-auto mb-3" />
              <p className="text-slate-400 font-medium">No time entries yet</p>
              <p className="text-slate-600 text-sm mt-1">Start logging your billable hours</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-800">
                    <th className="text-left text-xs font-medium text-slate-500 px-5 py-3">Date</th>
                    <th className="text-left text-xs font-medium text-slate-500 px-5 py-3">Description</th>
                    <th className="text-left text-xs font-medium text-slate-500 px-5 py-3 hidden md:table-cell">Matter / Client</th>
                    <th className="text-right text-xs font-medium text-slate-500 px-5 py-3">Hours</th>
                    <th className="text-right text-xs font-medium text-slate-500 px-5 py-3 hidden sm:table-cell">Amount</th>
                    <th className="text-center text-xs font-medium text-slate-500 px-5 py-3">Billed</th>
                    <th className="px-5 py-3 w-20"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {timeEntries.map(entry => (
                    <tr key={entry.id} className="hover:bg-slate-800/40 transition-colors group">
                      <td className="px-5 py-3.5 text-sm text-slate-300 whitespace-nowrap">{fmtDate(entry.date)}</td>
                      <td className="px-5 py-3.5 text-sm text-white max-w-xs truncate">{entry.description}</td>
                      <td className="px-5 py-3.5 hidden md:table-cell">
                        <p className="text-sm text-slate-300 truncate">{(entry.matter as any)?.title}</p>
                        <p className="text-xs text-slate-500">{(entry.matter as any)?.client?.name}</p>
                      </td>
                      <td className="px-5 py-3.5 text-right text-sm font-medium text-white">{Number(entry.hours).toFixed(1)}h</td>
                      <td className="px-5 py-3.5 text-right text-sm text-slate-300 hidden sm:table-cell">{fmt(Number(entry.hours) * Number(entry.rate))}</td>
                      <td className="px-5 py-3.5 text-center">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${entry.billed ? 'bg-emerald-500/15 text-emerald-400' : 'bg-slate-700/60 text-slate-400'}`}>
                          {entry.billed ? 'Yes' : 'No'}
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          {!entry.billed && (
                            <button onClick={() => openTimeEdit(entry)} className="p-1.5 text-slate-500 hover:text-slate-200 hover:bg-slate-700 rounded-md transition-colors">
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button onClick={() => setDeleteId({ type: 'time', id: entry.id })} className="p-1.5 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded-md transition-colors">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        ) : (
          expenses.length === 0 ? (
            <div className="p-12 text-center">
              <Receipt className="w-10 h-10 text-slate-700 mx-auto mb-3" />
              <p className="text-slate-400 font-medium">No expenses yet</p>
              <p className="text-slate-600 text-sm mt-1">Add filing fees, travel, and other out-of-pocket costs</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-800">
                    <th className="text-left text-xs font-medium text-slate-500 px-5 py-3">Date</th>
                    <th className="text-left text-xs font-medium text-slate-500 px-5 py-3">Description</th>
                    <th className="text-left text-xs font-medium text-slate-500 px-5 py-3 hidden md:table-cell">Matter</th>
                    <th className="text-right text-xs font-medium text-slate-500 px-5 py-3">Amount</th>
                    <th className="text-center text-xs font-medium text-slate-500 px-5 py-3">Billed</th>
                    <th className="px-5 py-3 w-20"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {expenses.map(exp => (
                    <tr key={exp.id} className="hover:bg-slate-800/40 transition-colors group">
                      <td className="px-5 py-3.5 text-sm text-slate-300 whitespace-nowrap">{fmtDate(exp.date)}</td>
                      <td className="px-5 py-3.5 text-sm text-white max-w-xs truncate">{exp.description}</td>
                      <td className="px-5 py-3.5 hidden md:table-cell">
                        <p className="text-sm text-slate-300">{(exp.matter as any)?.title}</p>
                        <p className="text-xs text-slate-500">{(exp.matter as any)?.client?.name}</p>
                      </td>
                      <td className="px-5 py-3.5 text-right text-sm font-semibold text-white">{fmt(exp.amount)}</td>
                      <td className="px-5 py-3.5 text-center">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${exp.billed ? 'bg-emerald-500/15 text-emerald-400' : 'bg-slate-700/60 text-slate-400'}`}>
                          {exp.billed ? 'Yes' : 'No'}
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          {!exp.billed && (
                            <button onClick={() => openExpEdit(exp)} className="p-1.5 text-slate-500 hover:text-slate-200 hover:bg-slate-700 rounded-md transition-colors">
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button onClick={() => setDeleteId({ type: 'expenses', id: exp.id })} className="p-1.5 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded-md transition-colors">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        )}
      </div>

      {/* Time Modal */}
      <Modal open={timeModal} onClose={() => setTimeModal(false)} title={editingTime ? 'Edit Time Entry' : 'Log Time'}>
        <div className="p-6 space-y-4">
          {error && <div className="px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm">{error}</div>}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Matter *</label>
            <select
              value={timeForm.matter_id}
              onChange={e => {
                const m = matters.find(m => m.id === e.target.value);
                setTimeForm(f => ({ ...f, matter_id: e.target.value, rate: String(m?.hourly_rate ?? f.rate) }));
              }}
              className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
            >
              <option value="">Select matter...</option>
              {matters.map(m => <option key={m.id} value={m.id}>{m.title} — {(m.client as any)?.name}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Date *</label>
              <input type="date" value={timeForm.date} onChange={e => setTimeForm(f => ({ ...f, date: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Hours *</label>
              <input type="number" step="0.25" min="0.25" value={timeForm.hours} onChange={e => setTimeForm(f => ({ ...f, hours: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500" placeholder="2.5" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Rate (₹/hr)</label>
            <input type="number" value={timeForm.rate} onChange={e => setTimeForm(f => ({ ...f, rate: e.target.value }))}
              className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500" placeholder="5000" />
            {timeForm.hours && timeForm.rate && (
              <p className="text-xs text-amber-400 mt-1">
                Total: {new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(parseFloat(timeForm.hours) * parseFloat(timeForm.rate))}
              </p>
            )}
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Description *</label>
            <textarea value={timeForm.description} onChange={e => setTimeForm(f => ({ ...f, description: e.target.value }))}
              rows={3}
              className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 resize-none"
              placeholder="e.g. Appeared before Delhi High Court for hearing on interim injunction application" />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setTimeModal(false)} className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200 transition-colors">Cancel</button>
            <button onClick={saveTime} disabled={saving} className="px-4 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-900 font-semibold text-sm rounded-lg transition-colors">
              {saving ? 'Saving...' : editingTime ? 'Update Entry' : 'Log Time'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Expense Modal */}
      <Modal open={expModal} onClose={() => setExpModal(false)} title={editingExp ? 'Edit Expense' : 'Add Expense'}>
        <div className="p-6 space-y-4">
          {error && <div className="px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm">{error}</div>}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Matter *</label>
            <select value={expForm.matter_id} onChange={e => setExpForm(f => ({ ...f, matter_id: e.target.value }))}
              className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500">
              <option value="">Select matter...</option>
              {matters.map(m => <option key={m.id} value={m.id}>{m.title} — {(m.client as any)?.name}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Date *</label>
              <input type="date" value={expForm.date} onChange={e => setExpForm(f => ({ ...f, date: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Amount (₹) *</label>
              <input type="number" value={expForm.amount} onChange={e => setExpForm(f => ({ ...f, amount: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500" placeholder="1500" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Description *</label>
            <textarea value={expForm.description} onChange={e => setExpForm(f => ({ ...f, description: e.target.value }))}
              rows={3}
              className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 resize-none"
              placeholder="e.g. Court fee for filing writ petition" />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setExpModal(false)} className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200 transition-colors">Cancel</button>
            <button onClick={saveExp} disabled={saving} className="px-4 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-900 font-semibold text-sm rounded-lg transition-colors">
              {saving ? 'Saving...' : editingExp ? 'Update Expense' : 'Add Expense'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Delete confirm */}
      <Modal open={!!deleteId} onClose={() => setDeleteId(null)} title="Delete Entry" size="sm">
        <div className="p-6">
          <p className="text-slate-300 text-sm mb-6">Delete this entry? This cannot be undone.</p>
          <div className="flex justify-end gap-3">
            <button onClick={() => setDeleteId(null)} className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200 transition-colors">Cancel</button>
            <button onClick={confirmDelete} className="px-4 py-2 bg-red-500 hover:bg-red-400 text-white font-semibold text-sm rounded-lg transition-colors">Delete</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
