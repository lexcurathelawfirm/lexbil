import { useEffect, useState } from 'react';
import { Users, Briefcase, FileText, TrendingUp, Clock, AlertCircle } from 'lucide-react';
import { api } from '../lib/api';
import StatusBadge from '../components/StatusBadge';
import type { Invoice, TimeEntry } from '../types';

interface Stats {
  totalClients: number;
  activeMatters: number;
  openInvoices: number;
  totalOutstanding: number;
  unbilledHours: number;
  overdueAmount: number;
}

function fmt(n: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
}

function fmtDate(s: string) {
  return new Date(s).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export default function Dashboard({ onNavigate }: { onNavigate: (p: any) => void }) {
  const [stats, setStats] = useState<Stats>({ totalClients: 0, activeMatters: 0, openInvoices: 0, totalOutstanding: 0, unbilledHours: 0, overdueAmount: 0 });
  const [recentInvoices, setRecentInvoices] = useState<Invoice[]>([]);
  const [recentTime, setRecentTime] = useState<TimeEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadDashboard(); }, []);

  async function loadDashboard() {
    setLoading(true);
    try {
      const [statsData, invoices, time] = await Promise.all([
        api.getDashboardStats(),
        api.getRecentInvoices(5),
        api.getRecentUnbilledTime(5),
      ]);
      setStats(statsData);
      setRecentInvoices(invoices);
      setRecentTime(time);
    } finally {
      setLoading(false);
    }
  }

  const statCards = [
    { label: 'Total Outstanding', value: fmt(stats.totalOutstanding), icon: TrendingUp, color: 'text-amber-400', bg: 'bg-amber-500/10' },
    { label: 'Active Clients', value: stats.totalClients, icon: Users, color: 'text-blue-400', bg: 'bg-blue-500/10' },
    { label: 'Active Matters', value: stats.activeMatters, icon: Briefcase, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
    { label: 'Open Invoices', value: stats.openInvoices, icon: FileText, color: 'text-slate-300', bg: 'bg-slate-700/60' },
    { label: 'Unbilled Hours', value: `${stats.unbilledHours.toFixed(1)}h`, icon: Clock, color: 'text-orange-400', bg: 'bg-orange-500/10' },
    { label: 'Overdue Amount', value: fmt(stats.overdueAmount), icon: AlertCircle, color: 'text-red-400', bg: 'bg-red-500/10' },
  ];

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-slate-400 text-sm mt-1">Overview of your practice billing</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {statCards.map(({ label, value, icon: Icon, color, bg }) => (
          <div key={label} className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-colors">
            <div className="flex items-start justify-between mb-3">
              <div className={`p-2 rounded-lg ${bg}`}>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
            </div>
            <p className={`text-2xl font-bold ${color}`}>{loading ? '—' : value}</p>
            <p className="text-slate-500 text-xs mt-1">{label}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Invoices */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
            <h2 className="text-sm font-semibold text-white">Recent Invoices</h2>
            <button onClick={() => onNavigate('invoices')} className="text-xs text-amber-400 hover:text-amber-300 transition-colors">View all</button>
          </div>
          <div className="divide-y divide-slate-800">
            {loading ? (
              <div className="px-5 py-8 text-center text-slate-500 text-sm">Loading...</div>
            ) : recentInvoices.length === 0 ? (
              <div className="px-5 py-8 text-center text-slate-500 text-sm">No invoices yet</div>
            ) : recentInvoices.map(inv => (
              <div key={inv.id} className="flex items-center justify-between px-5 py-3 hover:bg-slate-800/50 transition-colors">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-white truncate">{inv.invoice_number}</p>
                  <p className="text-xs text-slate-500 truncate">{(inv.client as any)?.name} · {fmtDate(inv.issue_date)}</p>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0 ml-3">
                  <StatusBadge status={inv.status} />
                  <span className="text-sm font-semibold text-white">{fmt(inv.total)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Time Entries */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
            <h2 className="text-sm font-semibold text-white">Unbilled Time</h2>
            <button onClick={() => onNavigate('time')} className="text-xs text-amber-400 hover:text-amber-300 transition-colors">View all</button>
          </div>
          <div className="divide-y divide-slate-800">
            {loading ? (
              <div className="px-5 py-8 text-center text-slate-500 text-sm">Loading...</div>
            ) : recentTime.length === 0 ? (
              <div className="px-5 py-8 text-center text-slate-500 text-sm">No unbilled time entries</div>
            ) : recentTime.map(entry => (
              <div key={entry.id} className="flex items-center justify-between px-5 py-3 hover:bg-slate-800/50 transition-colors">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-white truncate">{entry.description}</p>
                  <p className="text-xs text-slate-500 truncate">
                    {(entry.matter as any)?.client?.name} · {fmtDate(entry.date)}
                  </p>
                </div>
                <div className="flex-shrink-0 ml-3 text-right">
                  <p className="text-sm font-semibold text-white">{entry.hours}h</p>
                  <p className="text-xs text-slate-500">{fmt(Number(entry.hours) * Number(entry.rate))}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
