import { useEffect, useState } from 'react';
import { Save, Scale } from 'lucide-react';
import { api } from '../lib/api';
import type { AdvocateProfile } from '../types';

type FormData = Omit<AdvocateProfile, 'id' | 'user_id' | 'created_at' | 'updated_at' | 'invoice_counter'>;

const empty: FormData = {
  name: '', practice_name: '', bar_council_number: '', address: '', phone: '',
  email: '', gstin: '', bank_name: '', bank_account: '', bank_ifsc: '', invoice_prefix: 'INV',
};

export default function Settings() {
  const [form, setForm] = useState<FormData>(empty);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    const data = await api.getProfile();
    if (data) {
      setForm({
        name: data.name, practice_name: data.practice_name, bar_council_number: data.bar_council_number,
        address: data.address, phone: data.phone, email: data.email, gstin: data.gstin,
        bank_name: data.bank_name, bank_account: data.bank_account, bank_ifsc: data.bank_ifsc,
        invoice_prefix: data.invoice_prefix,
      });
    }
    setLoading(false);
  }

  async function save() {
    setSaving(true);
    setError('');
    setSaved(false);
    try {
      await api.upsertProfile(form);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="p-12 text-center text-slate-500 text-sm">Loading...</div>;

  function field(label: string, key: keyof FormData, props: any = {}) {
    return (
      <div>
        <label className="block text-xs font-medium text-slate-400 mb-1.5">{label}</label>
        {props.textarea ? (
          <textarea
            value={form[key] as string}
            onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
            rows={3}
            className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 resize-none"
            placeholder={props.placeholder}
          />
        ) : (
          <input
            type={props.type ?? 'text'}
            value={form[key] as string}
            onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
            className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
            placeholder={props.placeholder}
          />
        )}
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-8 max-w-3xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Settings</h1>
        <p className="text-slate-400 text-sm mt-1">Practice details used on invoices and letterheads</p>
      </div>

      {error && <div className="mb-4 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm">{error}</div>}
      {saved && <div className="mb-4 px-4 py-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-emerald-400 text-sm">Settings saved successfully.</div>}

      <div className="space-y-6">
        {/* Profile card */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-5">
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <Scale className="w-4 h-4 text-amber-400" />
            </div>
            <h2 className="text-sm font-semibold text-white">Practice Information</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {field('Your Full Name', 'name', { placeholder: 'Adv. Rajesh Kumar' })}
            {field('Practice / Firm Name', 'practice_name', { placeholder: 'Kumar & Associates' })}
            {field('Bar Council Enrolment Number', 'bar_council_number', { placeholder: 'D/1234/2010' })}
            <div className="sm:col-span-2">
              {field('Office Address', 'address', { textarea: true, placeholder: 'Chamber No. 12, High Court Complex, New Delhi - 110001' })}
            </div>
            {field('Phone', 'phone', { placeholder: '+91 98765 43210' })}
            {field('Email', 'email', { type: 'email', placeholder: 'adv.rajesh@email.com' })}
            {field('GSTIN', 'gstin', { placeholder: '07AAAAA0000A1Z5' })}
          </div>
        </div>

        {/* Bank details */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <h2 className="text-sm font-semibold text-white mb-5">Bank Details</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {field('Bank Name', 'bank_name', { placeholder: 'State Bank of India' })}
            {field('Account Number', 'bank_account', { placeholder: '1234567890' })}
            {field('IFSC Code', 'bank_ifsc', { placeholder: 'SBIN0001234' })}
          </div>
        </div>

        {/* Invoice settings */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <h2 className="text-sm font-semibold text-white mb-5">Invoice Settings</h2>
          <div className="max-w-xs">
            {field('Invoice Number Prefix', 'invoice_prefix', { placeholder: 'INV' })}
            <p className="text-xs text-slate-500 mt-1">Invoices will be numbered: {form.invoice_prefix || 'INV'}-0001, {form.invoice_prefix || 'INV'}-0002, ...</p>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            onClick={save}
            disabled={saving}
            className="flex items-center gap-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-900 font-semibold px-6 py-2.5 rounded-lg text-sm transition-colors"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </div>
    </div>
  );
}
