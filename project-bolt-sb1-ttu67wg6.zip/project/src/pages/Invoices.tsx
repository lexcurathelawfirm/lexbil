import { useEffect, useState } from 'react';
import { Plus, Search, Eye, Trash2, CheckCircle, Send, CreditCard, FileText } from 'lucide-react';
import { api } from '../lib/api';
import Modal from '../components/Modal';
import StatusBadge from '../components/StatusBadge';
import type { Invoice, Client, InvoiceStatus } from '../types';

function fmt(n: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
}
function fmtDate(s: string) {
  return new Date(s + 'T00:00:00').toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

interface LineItem { description: string; quantity: string; rate: string; time_entry_id?: string; expense_id?: string; }

const statusFlow: Record<string, InvoiceStatus[]> = {
  draft: ['sent', 'cancelled'],
  sent: ['paid', 'overdue', 'cancelled'],
  overdue: ['paid', 'cancelled'],
  paid: [],
  cancelled: [],
};

export default function Invoices({ onView }: { onView: (id: string) => void }) {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Create modal
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ client_id: '', issue_date: new Date().toISOString().slice(0, 10), due_date: '', tax_rate: '18', notes: '' });
  const [lineItems, setLineItems] = useState<LineItem[]>([{ description: '', quantity: '1', rate: '' }]);
  const [unbilledTime, setUnbilledTime] = useState<any[]>([]);
  const [unbilledExp, setUnbilledExp] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [createError, setCreateError] = useState('');

  // Payment modal
  const [payModal, setPayModal] = useState<Invoice | null>(null);
  const [payForm, setPayForm] = useState({ date: new Date().toISOString().slice(0, 10), amount: '', method: 'bank_transfer', reference: '', notes: '' });
  const [payError, setPayError] = useState('');

  // Status modal
  const [statusModal, setStatusModal] = useState<{ inv: Invoice; status: InvoiceStatus } | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    const [invData, clientData] = await Promise.all([api.getInvoices(), api.getClients()]);
    setInvoices(invData);
    setClients(clientData);
    setLoading(false);
  }

  async function loadUnbilled(clientId: string) {
    const [t, e] = await Promise.all([
      api.getUnbilledTimeForClient(clientId),
      api.getUnbilledExpensesForClient(clientId),
    ]);
    setUnbilledTime(t);
    setUnbilledExp(e);
  }

  async function openCreate() {
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 30);
    const firstClient = clients[0];
    setForm({ client_id: firstClient?.id ?? '', issue_date: new Date().toISOString().slice(0, 10), due_date: dueDate.toISOString().slice(0, 10), tax_rate: '18', notes: '' });
    setLineItems([{ description: '', quantity: '1', rate: '' }]);
    setCreateError('');
    if (firstClient) await loadUnbilled(firstClient.id);
    else { setUnbilledTime([]); setUnbilledExp([]); }
    setCreateOpen(true);
  }

  function addUnbilledTime(entry: any) {
    setLineItems(prev => [...prev, { description: `[Time] ${entry.matter?.title} — ${entry.description}`, quantity: String(entry.hours), rate: String(entry.rate), time_entry_id: entry.id }]);
  }

  function addUnbilledExp(exp: any) {
    setLineItems(prev => [...prev, { description: `[Expense] ${exp.matter?.title} — ${exp.description}`, quantity: '1', rate: String(exp.amount), expense_id: exp.id }]);
  }

  function calcTotals() {
    const subtotal = lineItems.reduce((s, item) => s + (parseFloat(item.quantity) || 0) * (parseFloat(item.rate) || 0), 0);
    const taxRate = parseFloat(form.tax_rate) || 0;
    const taxAmount = subtotal * taxRate / 100;
    const total = subtotal + taxAmount;
    return { subtotal, taxAmount, total };
  }

  async function createInvoice() {
    if (!form.client_id) { setCreateError('Select a client.'); return; }
    const validItems = lineItems.filter(i => i.description && (parseFloat(i.quantity) > 0) && (parseFloat(i.rate) >= 0));
    if (validItems.length === 0) { setCreateError('Add at least one line item with description, quantity, and rate.'); return; }
    setSaving(true);
    setCreateError('');
    try {
      const invoiceNumber = await api.getNextInvoiceNumber();
      const { subtotal, taxAmount, total } = calcTotals();
      const invoiceData = {
        client_id: form.client_id,
        invoice_number: invoiceNumber,
        issue_date: form.issue_date,
        due_date: form.due_date,
        status: 'draft' as InvoiceStatus,
        subtotal,
        tax_rate: parseFloat(form.tax_rate) || 0,
        tax_amount: taxAmount,
        total,
        notes: form.notes,
      };
      const items = validItems.map(i => ({
        invoice_id: '',
        description: i.description,
        quantity: parseFloat(i.quantity),
        rate: parseFloat(i.rate),
        amount: parseFloat(i.quantity) * parseFloat(i.rate),
        time_entry_id: i.time_entry_id ?? null,
        expense_id: i.expense_id ?? null,
      }));
      await api.createInvoice(invoiceData, items);
      setCreateOpen(false);
      load();
    } catch (err: any) {
      setCreateError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function updateStatus(inv: Invoice, status: InvoiceStatus) {
    await api.updateInvoiceStatus(inv.id, status);
    setStatusModal(null);
    load();
  }

  async function recordPayment() {
    if (!payModal) return;
    if (!payForm.amount) { setPayError('Enter payment amount.'); return; }
    setSaving(true);
    setPayError('');
    await api.createPayment({
      invoice_id: payModal.id,
      date: payForm.date,
      amount: parseFloat(payForm.amount),
      method: payForm.method,
      reference: payForm.reference,
      notes: payForm.notes,
    });
    setSaving(false);
    setPayModal(null);
    load();
  }

  async function deleteInvoice(id: string) {
    await api.deleteInvoice(id);
    setDeleteConfirm(null);
    load();
  }

  const filtered = invoices.filter(inv => {
    const matchSearch = inv.invoice_number.toLowerCase().includes(search.toLowerCase()) ||
      (inv.client as any)?.name?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || inv.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const { subtotal, taxAmount, total } = calcTotals();

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Invoices</h1>
          <p className="text-slate-400 text-sm mt-1">{invoices.length} invoice{invoices.length !== 1 ? 's' : ''}</p>
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold px-4 py-2 rounded-lg text-sm transition-colors">
          <Plus className="w-4 h-4" />
          New Invoice
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search invoices..."
            className="w-full sm:w-64 bg-slate-900 border border-slate-800 text-white placeholder-slate-500 rounded-lg pl-9 pr-4 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-colors" />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {['all', 'draft', 'sent', 'overdue', 'paid', 'cancelled'].map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors capitalize ${statusFilter === s ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'text-slate-400 hover:text-slate-200 border border-slate-800 hover:border-slate-700'}`}>
              {s === 'all' ? 'All' : s}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-500 text-sm">Loading...</div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center">
            <FileText className="w-10 h-10 text-slate-700 mx-auto mb-3" />
            <p className="text-slate-400 font-medium">No invoices found</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="text-left text-xs font-medium text-slate-500 px-5 py-3">Invoice</th>
                  <th className="text-left text-xs font-medium text-slate-500 px-5 py-3 hidden sm:table-cell">Client</th>
                  <th className="text-left text-xs font-medium text-slate-500 px-5 py-3 hidden md:table-cell">Issue Date</th>
                  <th className="text-left text-xs font-medium text-slate-500 px-5 py-3 hidden lg:table-cell">Due Date</th>
                  <th className="text-left text-xs font-medium text-slate-500 px-5 py-3">Status</th>
                  <th className="text-right text-xs font-medium text-slate-500 px-5 py-3">Amount</th>
                  <th className="px-5 py-3 w-32"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filtered.map(inv => (
                  <tr key={inv.id} className="hover:bg-slate-800/40 transition-colors group">
                    <td className="px-5 py-3.5">
                      <p className="text-sm font-semibold text-white">{inv.invoice_number}</p>
                    </td>
                    <td className="px-5 py-3.5 hidden sm:table-cell text-sm text-slate-300">{(inv.client as any)?.name}</td>
                    <td className="px-5 py-3.5 hidden md:table-cell text-sm text-slate-400">{fmtDate(inv.issue_date)}</td>
                    <td className="px-5 py-3.5 hidden lg:table-cell text-sm text-slate-400">{fmtDate(inv.due_date)}</td>
                    <td className="px-5 py-3.5"><StatusBadge status={inv.status} /></td>
                    <td className="px-5 py-3.5 text-right text-sm font-bold text-white">{fmt(inv.total)}</td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity justify-end">
                        <button onClick={() => onView(inv.id)} title="View" className="p-1.5 text-slate-500 hover:text-slate-200 hover:bg-slate-700 rounded-md transition-colors">
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {statusFlow[inv.status]?.includes('sent') && (
                          <button onClick={() => setStatusModal({ inv, status: 'sent' })} title="Mark Sent" className="p-1.5 text-slate-500 hover:text-blue-400 hover:bg-blue-500/10 rounded-md transition-colors">
                            <Send className="w-3.5 h-3.5" />
                          </button>
                        )}
                        {(inv.status === 'sent' || inv.status === 'overdue') && (
                          <button onClick={() => { setPayModal(inv); setPayForm(f => ({ ...f, amount: String(inv.total) })); }} title="Record Payment" className="p-1.5 text-slate-500 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-md transition-colors">
                            <CreditCard className="w-3.5 h-3.5" />
                          </button>
                        )}
                        {statusFlow[inv.status]?.includes('paid') && inv.status !== 'sent' && (
                          <button onClick={() => setStatusModal({ inv, status: 'paid' })} title="Mark Paid" className="p-1.5 text-slate-500 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-md transition-colors">
                            <CheckCircle className="w-3.5 h-3.5" />
                          </button>
                        )}
                        {inv.status === 'draft' && (
                          <button onClick={() => setDeleteConfirm(inv.id)} title="Delete" className="p-1.5 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded-md transition-colors">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create Invoice Modal */}
      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="New Invoice" size="xl">
        <div className="p-6 space-y-5">
          {createError && <div className="px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm">{createError}</div>}

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="col-span-2">
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Client *</label>
              <select value={form.client_id} onChange={async e => { setForm(f => ({ ...f, client_id: e.target.value })); await loadUnbilled(e.target.value); }}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500">
                <option value="">Select client...</option>
                {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Issue Date</label>
              <input type="date" value={form.issue_date} onChange={e => setForm(f => ({ ...f, issue_date: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Due Date</label>
              <input type="date" value={form.due_date} onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500" />
            </div>
          </div>

          {/* Unbilled items */}
          {form.client_id && (unbilledTime.length > 0 || unbilledExp.length > 0) && (
            <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4">
              <p className="text-xs font-medium text-slate-400 mb-3">Add unbilled items from this client</p>
              <div className="space-y-1 max-h-40 overflow-y-auto pr-1">
                {unbilledTime.map((t: any) => (
                  <div key={t.id} className="flex items-center justify-between py-1.5 px-3 rounded-lg hover:bg-slate-700/60 transition-colors">
                    <div className="min-w-0">
                      <p className="text-xs text-slate-300 truncate">{t.matter?.title} — {t.description}</p>
                      <p className="text-xs text-slate-500">{t.hours}h @ ₹{t.rate}/hr = {fmt(t.hours * t.rate)}</p>
                    </div>
                    <button onClick={() => addUnbilledTime(t)} disabled={lineItems.some(i => i.time_entry_id === t.id)}
                      className="ml-3 flex-shrink-0 text-xs px-2 py-1 bg-amber-500/20 text-amber-400 rounded-md hover:bg-amber-500/30 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                      {lineItems.some(i => i.time_entry_id === t.id) ? 'Added' : 'Add'}
                    </button>
                  </div>
                ))}
                {unbilledExp.map((e: any) => (
                  <div key={e.id} className="flex items-center justify-between py-1.5 px-3 rounded-lg hover:bg-slate-700/60 transition-colors">
                    <div className="min-w-0">
                      <p className="text-xs text-slate-300 truncate">{e.matter?.title} — {e.description}</p>
                      <p className="text-xs text-slate-500">Expense: {fmt(e.amount)}</p>
                    </div>
                    <button onClick={() => addUnbilledExp(e)} disabled={lineItems.some(i => i.expense_id === e.id)}
                      className="ml-3 flex-shrink-0 text-xs px-2 py-1 bg-blue-500/20 text-blue-400 rounded-md hover:bg-blue-500/30 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                      {lineItems.some(i => i.expense_id === e.id) ? 'Added' : 'Add'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Line items */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-slate-400">Line Items *</label>
              <button onClick={() => setLineItems(prev => [...prev, { description: '', quantity: '1', rate: '' }])}
                className="text-xs text-amber-400 hover:text-amber-300 transition-colors">+ Add row</button>
            </div>
            <div className="space-y-2">
              <div className="grid grid-cols-12 gap-2 px-1">
                <div className="col-span-7 text-xs text-slate-500">Description</div>
                <div className="col-span-2 text-xs text-slate-500 text-right">Qty</div>
                <div className="col-span-2 text-xs text-slate-500 text-right">Rate (₹)</div>
                <div className="col-span-1"></div>
              </div>
              {lineItems.map((item, i) => (
                <div key={i} className="grid grid-cols-12 gap-2 items-center">
                  <div className="col-span-7">
                    <input value={item.description} onChange={e => setLineItems(prev => prev.map((l, j) => j === i ? { ...l, description: e.target.value } : l))}
                      className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                      placeholder="Description of service" />
                  </div>
                  <div className="col-span-2">
                    <input type="number" step="0.25" min="0" value={item.quantity} onChange={e => setLineItems(prev => prev.map((l, j) => j === i ? { ...l, quantity: e.target.value } : l))}
                      className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-right" />
                  </div>
                  <div className="col-span-2">
                    <input type="number" min="0" value={item.rate} onChange={e => setLineItems(prev => prev.map((l, j) => j === i ? { ...l, rate: e.target.value } : l))}
                      className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-right" />
                  </div>
                  <div className="col-span-1 flex justify-center">
                    {lineItems.length > 1 && (
                      <button onClick={() => setLineItems(prev => prev.filter((_, j) => j !== i))}
                        className="text-slate-600 hover:text-red-400 transition-colors text-lg leading-none">&times;</button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Totals */}
          <div className="flex flex-col items-end gap-1.5 border-t border-slate-800 pt-4">
            <div className="flex items-center gap-8 text-sm">
              <span className="text-slate-400">Subtotal</span>
              <span className="text-white w-28 text-right">{fmt(subtotal)}</span>
            </div>
            <div className="flex items-center gap-4 text-sm">
              <span className="text-slate-400">GST</span>
              <div className="flex items-center gap-2">
                <input type="number" value={form.tax_rate} onChange={e => setForm(f => ({ ...f, tax_rate: e.target.value }))}
                  className="w-16 bg-slate-800 border border-slate-700 text-white rounded px-2 py-1 text-sm text-center focus:outline-none focus:border-amber-500" />
                <span className="text-slate-500">%</span>
              </div>
              <span className="text-white w-28 text-right">{fmt(taxAmount)}</span>
            </div>
            <div className="flex items-center gap-8 text-base font-bold border-t border-slate-700 pt-2 mt-1">
              <span className="text-white">Total</span>
              <span className="text-amber-400 w-28 text-right">{fmt(total)}</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Notes</label>
            <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2}
              className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 resize-none"
              placeholder="Payment instructions or any additional notes..." />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setCreateOpen(false)} className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200 transition-colors">Cancel</button>
            <button onClick={createInvoice} disabled={saving} className="px-4 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-900 font-semibold text-sm rounded-lg transition-colors">
              {saving ? 'Creating...' : 'Create Invoice'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Status change modal */}
      <Modal open={!!statusModal} onClose={() => setStatusModal(null)} title="Update Invoice Status" size="sm">
        <div className="p-6">
          <p className="text-slate-300 text-sm mb-6">
            Mark invoice <span className="font-semibold text-white">{statusModal?.inv.invoice_number}</span> as{' '}
            <span className="capitalize font-semibold text-white">{statusModal?.status}</span>?
          </p>
          <div className="flex justify-end gap-3">
            <button onClick={() => setStatusModal(null)} className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200 transition-colors">Cancel</button>
            <button onClick={() => updateStatus(statusModal!.inv, statusModal!.status)} className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold text-sm rounded-lg transition-colors">Confirm</button>
          </div>
        </div>
      </Modal>

      {/* Payment modal */}
      <Modal open={!!payModal} onClose={() => setPayModal(null)} title="Record Payment">
        <div className="p-6 space-y-4">
          {payError && <div className="px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm">{payError}</div>}
          <p className="text-sm text-slate-400">Invoice: <span className="text-white font-medium">{payModal?.invoice_number}</span> — Total: <span className="text-amber-400 font-bold">{fmt(payModal?.total ?? 0)}</span></p>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Date *</label>
              <input type="date" value={payForm.date} onChange={e => setPayForm(f => ({ ...f, date: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Amount (₹) *</label>
              <input type="number" value={payForm.amount} onChange={e => setPayForm(f => ({ ...f, amount: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Method</label>
              <select value={payForm.method} onChange={e => setPayForm(f => ({ ...f, method: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500">
                <option value="bank_transfer">Bank Transfer</option>
                <option value="upi">UPI</option>
                <option value="cheque">Cheque</option>
                <option value="cash">Cash</option>
                <option value="demand_draft">Demand Draft</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Reference / UTR</label>
              <input value={payForm.reference} onChange={e => setPayForm(f => ({ ...f, reference: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                placeholder="UTR or cheque no." />
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setPayModal(null)} className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200 transition-colors">Cancel</button>
            <button onClick={recordPayment} disabled={saving} className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-white font-semibold text-sm rounded-lg transition-colors">
              {saving ? 'Saving...' : 'Record Payment'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Delete modal */}
      <Modal open={!!deleteConfirm} onClose={() => setDeleteConfirm(null)} title="Delete Invoice" size="sm">
        <div className="p-6">
          <p className="text-slate-300 text-sm mb-6">Delete this draft invoice? This cannot be undone.</p>
          <div className="flex justify-end gap-3">
            <button onClick={() => setDeleteConfirm(null)} className="px-4 py-2 text-sm text-slate-400 hover:text-slate-200 transition-colors">Cancel</button>
            <button onClick={() => deleteInvoice(deleteConfirm!)} className="px-4 py-2 bg-red-500 hover:bg-red-400 text-white font-semibold text-sm rounded-lg transition-colors">Delete</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
