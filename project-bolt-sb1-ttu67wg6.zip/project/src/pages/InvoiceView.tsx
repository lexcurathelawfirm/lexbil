import { useEffect, useState } from 'react';
import { ArrowLeft, Printer, Scale } from 'lucide-react';
import { api } from '../lib/api';
import StatusBadge from '../components/StatusBadge';
import type { Invoice, InvoiceItem, Payment, AdvocateProfile } from '../types';

function fmt(n: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(n);
}
function fmtDate(s: string) {
  return new Date(s + 'T00:00:00').toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' });
}
function numToWords(n: number) {
  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
    'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  if (n === 0) return 'Zero';
  function convert(n: number): string {
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? ' ' + ones[n % 10] : '');
    if (n < 1000) return ones[Math.floor(n / 100)] + ' Hundred' + (n % 100 ? ' ' + convert(n % 100) : '');
    if (n < 100000) return convert(Math.floor(n / 1000)) + ' Thousand' + (n % 1000 ? ' ' + convert(n % 1000) : '');
    if (n < 10000000) return convert(Math.floor(n / 100000)) + ' Lakh' + (n % 100000 ? ' ' + convert(n % 100000) : '');
    return convert(Math.floor(n / 10000000)) + ' Crore' + (n % 10000000 ? ' ' + convert(n % 10000000) : '');
  }
  const rupees = Math.floor(n);
  const paise = Math.round((n - rupees) * 100);
  let words = 'Rupees ' + convert(rupees);
  if (paise > 0) words += ' and ' + convert(paise) + ' Paise';
  return words + ' Only';
}

export default function InvoiceView({ invoiceId, onBack }: { invoiceId: string; onBack: () => void }) {
  const [invoice, setInvoice] = useState<(Invoice & { items: InvoiceItem[]; payments: Payment[] }) | null>(null);
  const [profile, setProfile] = useState<AdvocateProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, [invoiceId]);

  async function load() {
    setLoading(true);
    const [inv, prof] = await Promise.all([
      api.getInvoice(invoiceId),
      api.getProfile(),
    ]);
    setInvoice(inv);
    setProfile(prof);
    setLoading(false);
  }

  if (loading) return <div className="p-12 text-center text-slate-500 text-sm">Loading invoice...</div>;
  if (!invoice) return <div className="p-12 text-center text-slate-500 text-sm">Invoice not found</div>;

  const client = invoice.client as any;
  const items = invoice.items ?? [];
  const payments = invoice.payments ?? [];
  const totalPaid = payments.reduce((s, p) => s + Number(p.amount), 0);
  const balance = Number(invoice.total) - totalPaid;

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Toolbar - hidden on print */}
      <div className="print:hidden flex items-center justify-between px-6 py-3 bg-slate-900 border-b border-slate-800">
        <button onClick={onBack} className="flex items-center gap-2 text-slate-400 hover:text-slate-200 transition-colors text-sm">
          <ArrowLeft className="w-4 h-4" />
          Back to Invoices
        </button>
        <div className="flex items-center gap-3">
          <StatusBadge status={invoice.status} />
          <button onClick={() => window.print()} className="flex items-center gap-2 bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold px-4 py-2 rounded-lg text-sm transition-colors">
            <Printer className="w-4 h-4" />
            Print / Save PDF
          </button>
        </div>
      </div>

      {/* Invoice document */}
      <div className="p-6 lg:p-10 max-w-4xl mx-auto">
        <div className="bg-white text-slate-900 rounded-2xl print:rounded-none shadow-2xl print:shadow-none overflow-hidden">
          {/* Header */}
          <div className="bg-slate-900 print:bg-slate-900 text-white px-8 py-6 flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <div className="flex items-center justify-center w-9 h-9 bg-amber-500 rounded-xl">
                  <Scale className="w-5 h-5 text-slate-900" />
                </div>
                <div>
                  <p className="font-bold text-white text-lg leading-tight">{profile?.practice_name || profile?.name || 'Advocate'}</p>
                  {profile?.bar_council_number && <p className="text-slate-400 text-xs">Bar Council No.: {profile.bar_council_number}</p>}
                </div>
              </div>
              {profile?.address && <p className="text-slate-400 text-sm whitespace-pre-line">{profile.address}</p>}
              {profile?.phone && <p className="text-slate-400 text-sm mt-1">{profile.phone}</p>}
              {profile?.email && <p className="text-slate-400 text-sm">{profile.email}</p>}
              {profile?.gstin && <p className="text-slate-400 text-sm mt-1">GSTIN: {profile.gstin}</p>}
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold text-amber-400">TAX INVOICE</p>
              <p className="text-2xl font-bold text-white mt-1">{invoice.invoice_number}</p>
            </div>
          </div>

          {/* Invoice details */}
          <div className="px-8 py-6 grid grid-cols-2 gap-6 border-b border-slate-200">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Bill To</p>
              <p className="font-bold text-slate-900 text-base">{client?.name}</p>
              {client?.address && <p className="text-slate-600 text-sm mt-1 whitespace-pre-line">{client.address}</p>}
              {client?.phone && <p className="text-slate-600 text-sm">{client.phone}</p>}
              {client?.email && <p className="text-slate-600 text-sm">{client.email}</p>}
              {client?.gstin && <p className="text-slate-600 text-sm mt-1">GSTIN: {client.gstin}</p>}
            </div>
            <div className="text-right space-y-2">
              <div>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Issue Date</p>
                <p className="font-semibold text-slate-800">{fmtDate(invoice.issue_date)}</p>
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Due Date</p>
                <p className="font-semibold text-slate-800">{fmtDate(invoice.due_date)}</p>
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</p>
                <p className={`font-bold text-sm capitalize ${invoice.status === 'paid' ? 'text-emerald-600' : invoice.status === 'overdue' ? 'text-red-600' : 'text-slate-800'}`}>
                  {invoice.status.toUpperCase()}
                </p>
              </div>
            </div>
          </div>

          {/* Line items */}
          <div className="px-8 py-4">
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-slate-200">
                  <th className="text-left text-xs font-bold text-slate-500 uppercase tracking-wider pb-3 w-8">#</th>
                  <th className="text-left text-xs font-bold text-slate-500 uppercase tracking-wider pb-3">Description</th>
                  <th className="text-right text-xs font-bold text-slate-500 uppercase tracking-wider pb-3 w-20">Qty/Hrs</th>
                  <th className="text-right text-xs font-bold text-slate-500 uppercase tracking-wider pb-3 w-28">Rate (₹)</th>
                  <th className="text-right text-xs font-bold text-slate-500 uppercase tracking-wider pb-3 w-28">Amount (₹)</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, i) => (
                  <tr key={item.id} className="border-b border-slate-100">
                    <td className="py-3 text-slate-400 text-sm">{i + 1}</td>
                    <td className="py-3 text-slate-800 text-sm">{item.description}</td>
                    <td className="py-3 text-right text-slate-600 text-sm">{Number(item.quantity).toFixed(2)}</td>
                    <td className="py-3 text-right text-slate-600 text-sm">{Number(item.rate).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                    <td className="py-3 text-right font-medium text-slate-800 text-sm">{Number(item.amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="px-8 pb-4">
            <div className="flex justify-end">
              <div className="w-64 space-y-2 border-t border-slate-200 pt-4">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Subtotal</span>
                  <span className="font-medium text-slate-800">{fmt(invoice.subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">GST ({invoice.tax_rate}%)</span>
                  <span className="font-medium text-slate-800">{fmt(invoice.tax_amount)}</span>
                </div>
                <div className="flex justify-between text-base font-bold border-t-2 border-slate-900 pt-2">
                  <span className="text-slate-900">Total</span>
                  <span className="text-slate-900">{fmt(invoice.total)}</span>
                </div>
                {totalPaid > 0 && (
                  <>
                    <div className="flex justify-between text-sm">
                      <span className="text-emerald-600">Amount Paid</span>
                      <span className="text-emerald-600 font-medium">{fmt(totalPaid)}</span>
                    </div>
                    <div className="flex justify-between text-sm font-bold">
                      <span className={balance > 0 ? 'text-red-600' : 'text-emerald-600'}>Balance Due</span>
                      <span className={balance > 0 ? 'text-red-600' : 'text-emerald-600'}>{fmt(balance)}</span>
                    </div>
                  </>
                )}
              </div>
            </div>
            <div className="mt-4 p-3 bg-slate-50 rounded-lg">
              <p className="text-xs text-slate-500 font-medium">Amount in words:</p>
              <p className="text-sm text-slate-700 font-medium mt-0.5">{numToWords(Number(invoice.total))}</p>
            </div>
          </div>

          {/* Notes */}
          {invoice.notes && (
            <div className="px-8 pb-4">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Notes</p>
              <p className="text-sm text-slate-600 whitespace-pre-line">{invoice.notes}</p>
            </div>
          )}

          {/* Bank details */}
          {profile?.bank_name && (
            <div className="px-8 pb-4">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Bank Details for Payment</p>
              <div className="grid grid-cols-3 gap-4 text-sm">
                {profile.bank_name && <div><p className="text-slate-400 text-xs">Bank</p><p className="text-slate-700 font-medium">{profile.bank_name}</p></div>}
                {profile.bank_account && <div><p className="text-slate-400 text-xs">Account No.</p><p className="text-slate-700 font-medium">{profile.bank_account}</p></div>}
                {profile.bank_ifsc && <div><p className="text-slate-400 text-xs">IFSC Code</p><p className="text-slate-700 font-medium">{profile.bank_ifsc}</p></div>}
              </div>
            </div>
          )}

          {/* Payments */}
          {payments.length > 0 && (
            <div className="px-8 pb-6 border-t border-slate-200 pt-4 print:hidden">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">Payment History</p>
              <div className="space-y-2">
                {payments.map(p => (
                  <div key={p.id} className="flex items-center justify-between text-sm">
                    <div>
                      <span className="text-slate-700 font-medium">{fmtDate(p.date)}</span>
                      <span className="text-slate-400 ml-2 capitalize">{p.method.replace('_', ' ')}</span>
                      {p.reference && <span className="text-slate-400 ml-2">Ref: {p.reference}</span>}
                    </div>
                    <span className="font-semibold text-emerald-600">{fmt(p.amount)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Footer */}
          <div className="px-8 py-4 bg-slate-50 border-t border-slate-200 text-center">
            <p className="text-xs text-slate-400">This is a computer generated invoice. No signature required.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
